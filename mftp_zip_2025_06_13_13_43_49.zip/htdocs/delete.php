<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $stmt = $pdo->prepare("DELETE FROM Student WHERE id = ?");
        $stmt->execute([$data->id]);
        echo json_encode(["success" => true, "message" => "Student deleted."]);
    } else {
        echo json_encode(["success" => false, "message" => "ID is required."]);
    }
}
?>
