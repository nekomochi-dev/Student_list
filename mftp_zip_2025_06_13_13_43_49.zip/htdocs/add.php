<?php
include 'db.php';
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->name) && !empty($data->email)) {
        $stmt = $pdo->prepare("INSERT INTO Student (name, email) VALUES (?, ?)");
        $stmt->execute([$data->name, $data->email]);
        echo json_encode(["success" => true, "message" => "Student added."]);
    } else {
        echo json_encode(["success" => false, "message" => "Missing fields."]);
    }
}
?>
