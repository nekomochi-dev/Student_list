<?php
$host = "sql208.infinityfree.com";      // Replace with your actual host (from MySQL Databases page)
$dbname = "if0_39204596_student_db";    // Replace with your actual database name
$username = "if0_39204596";             // Replace with your InfinityFree database username
$password = "Cf3xkKPIAPfhPOB";             // Replace with your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
